#!/bin/sh
# Laedt das Bild einmal und zeigt es kurz an (Oberflaeche bleibt aktiv).
DIR="$(cd "$(dirname "$0")" && pwd)"
. "$DIR/lib.sh"
lipc-set-prop com.lab126.cmd wirelessEnable 1 2>/dev/null
sleep 5
if holen; then
  log "Test: Bild geladen"
  anzeigen
  eips 1 1 "Test OK" >/dev/null 2>&1
else
  log "Test: Download fehlgeschlagen"
  eips 1 1 "Download fehlgeschlagen - siehe wetter.log" >/dev/null 2>&1
fi
