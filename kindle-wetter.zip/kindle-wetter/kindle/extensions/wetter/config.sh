#!/bin/sh
# HIER ANPASSEN: Adresse des Bildes (dein GitHub-Benutzername und Repo-Name)
IMAGE_URL="https://DEIN-BENUTZERNAME.github.io/kindle-wetter/dashboard.png"

# Abstand zwischen zwei Abrufen in Sekunden (900 = 15 Minuten)
INTERVALL=900
