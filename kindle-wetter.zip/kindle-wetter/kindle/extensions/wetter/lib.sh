#!/bin/sh
# Gemeinsame Funktionen
DIR="$(cd "$(dirname "$0")" && pwd)"
. "$DIR/config.sh"
IMG="$DIR/dashboard.png"
LOG="$DIR/wetter.log"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"
  # Log klein halten
  if [ "$(wc -c < "$LOG" 2>/dev/null || echo 0)" -gt 20000 ]; then
    tail -n 50 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
  fi
}

# Bild herunterladen. Zertifikatspruefung ist aus, weil alte Kindles
# neue Zertifikate oft nicht kennen (es wird nur ein Wetterbild geladen).
holen() {
  URL="$IMAGE_URL?t=$(date +%s)"
  rm -f "$IMG.neu"
  if command -v curl >/dev/null 2>&1; then
    curl -k -s -f -m 60 -o "$IMG.neu" "$URL"
  elif command -v wget >/dev/null 2>&1; then
    wget -q -T 60 --no-check-certificate -O "$IMG.neu" "$URL"
  else
    log "Weder curl noch wget gefunden"
    return 1
  fi
  if [ -s "$IMG.neu" ]; then
    mv "$IMG.neu" "$IMG"
    return 0
  fi
  rm -f "$IMG.neu"
  return 1
}

anzeigen() {
  eips -f -g "$IMG" >/dev/null 2>&1
}
