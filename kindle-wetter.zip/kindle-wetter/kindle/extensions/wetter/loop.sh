#!/bin/sh
# Dauerbetrieb: Bild alle INTERVALL Sekunden holen und anzeigen.
DIR="$(cd "$(dirname "$0")" && pwd)"
. "$DIR/lib.sh"

log "Start"
# Oberflaeche anhalten, damit das Bild stehen bleibt
stop framework >/dev/null 2>&1
# Standby/Bildschirmschoner verhindern
lipc-set-prop com.lab126.powerd preventScreenSaver 1 2>/dev/null
lipc-set-prop com.lab126.cmd wirelessEnable 1 2>/dev/null
sleep 10

while true; do
  if holen; then
    anzeigen
    log "Bild aktualisiert"
    sleep "$INTERVALL"
  else
    log "Download fehlgeschlagen, neuer Versuch in 60 s"
    lipc-set-prop com.lab126.cmd wirelessEnable 1 2>/dev/null
    sleep 60
  fi
done
