#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
nohup "$DIR/loop.sh" >/dev/null 2>&1 &
