# Kindle-Wetter für Berlin – vollautomatisch, ohne PC

**So funktioniert es:** GitHub erzeugt alle ~15 Minuten ein frisches Wetterbild (Berlin) und stellt es
im Internet bereit. Der Kindle holt sich das Bild selbst per WLAN und zeigt es an. Dein PC ist nicht beteiligt.

Voraussetzung: Kindle ist jailbroken, KUAL und MRPI sind installiert (KUAL erscheint in der Bibliothek).

> **Shortcut:** Doppelklick auf `setup-all.bat` erledigt Teil 1 und Teil 2 automatisch (Git und GitHub CLI werden bei Bedarf installiert, du meldest dich einmal bei GitHub an, der Kindle muss per USB angeschlossen sein). Die Schritte unten sind die manuelle Variante.

---

## Teil 1 – GitHub (einmalig, ca. 10 Minuten)

1. Kostenloses Konto auf **github.com** anlegen.
2. Neues Repository erstellen: Name `kindle-wetter`, Sichtbarkeit **Public**
   (für kostenlose Pages nötig; im Bild steht nur Wetter und Datum).
3. Diese Dateien in das Repository hochladen (*Add file → Upload files*, Ordner per Drag & Drop):
   - `dashboard.py`
   - `requirements.txt`
   - der Ordner `.github` (mit `workflows/dashboard.yml` darin)
4. Im Repository: **Settings → Pages → Source: „GitHub Actions"** auswählen.
5. Tab **Actions** öffnen, links „Kindle Dashboard" wählen, **Run workflow** klicken.
   Nach ca. 1 Minute sollte ein grüner Haken erscheinen.
6. Dein Bild ist jetzt erreichbar unter
   `https://DEIN-BENUTZERNAME.github.io/kindle-wetter/dashboard.png`
   (im Browser öffnen und prüfen).

## Teil 2 – Kindle

1. Kindle per USB anschließen.
2. Den Ordner `kindle/extensions/wetter` aus diesem Paket in den Ordner `extensions` auf dem Kindle kopieren
   (es entsteht `extensions/wetter` mit u. a. `menu.json` und `config.sh`).
3. Auf dem Kindle die Datei `extensions/wetter/config.sh` öffnen und bei `IMAGE_URL`
   `DEIN-BENUTZERNAME` durch deinen GitHub-Namen ersetzen.
   Datei mit einem Editor speichern, der Zeilenenden (LF) nicht verändert, z. B. Notepad++ oder VS Code.
4. Kindle auswerfen, **KUAL** öffnen → **Wetter → Testbild laden (einmalig)**.
   Nach einigen Sekunden sollte das Dashboard kurz erscheinen.
5. Läuft der Test: **Wetter → Wetter-Dashboard starten**.
   Der Kindle blendet die normale Oberfläche aus und aktualisiert das Bild alle 15 Minuten.

---

## Wichtig zu wissen

- **Stromversorgung:** Der Kindle bleibt im Dauerbetrieb mit WLAN an, das braucht Strom.
  Lass ihn am Ladekabel angeschlossen.
- **Beenden:** Die Oberfläche ist im Dashboard-Modus ausgeblendet, daher kein Menü zum Stoppen.
  Zum Beenden den Kindle neu starten (Ein-/Ausschalter ca. 40 Sekunden gedrückt halten).
- **Nach einem Neustart** startet das Dashboard nicht von selbst: KUAL öffnen und erneut „Wetter-Dashboard starten".
- **Fehlersuche:** Auf dem Kindle liegt die Datei `extensions/wetter/wetter.log`. Dort steht, ob der Abruf geklappt hat.
- **GitHub-Pause nach 60 Tagen:** GitHub schaltet geplante Läufe in Repositories ab, in denen 60 Tage nichts
  geändert wurde. Wenn das Bild nicht mehr aktuell wird: Im Tab Actions den Workflow wieder aktivieren
  oder eine kleine Änderung im Repository speichern.
- **Verzögerung:** GitHub führt geplante Läufe manchmal einige Minuten später aus. Das Bild ist daher
  höchstens etwa 15–25 Minuten alt. Es zeigt deshalb keine Uhr, sondern „Aktualisiert HH:MM Uhr".
- **Nicht am Gerät getestet:** Das Bildskript habe ich getestet. Die Kindle-Skripte (`eips`, `stop framework`)
  habe ich nach dem üblichen Vorgehen geschrieben, aber ohne Zugriff auf einen Kindle. Falls etwas nicht klappt,
  schick mir den Inhalt von `wetter.log` oder beschreibe, was der Bildschirm zeigt.
