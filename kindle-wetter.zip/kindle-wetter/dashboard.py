#!/usr/bin/env python3
"""Kindle-Wetter-Dashboard fuer Berlin.

Holt das aktuelle Wetter von Open-Meteo (kostenlos, ohne Schluessel) und
rendert ein Graustufen-PNG (1072 x 1448, Kindle Paperwhite 3).

    python dashboard.py          -> echtes Wetter
    python dashboard.py --demo   -> Testbild ohne Internet
"""
import json
import os
import sys
import urllib.request
from datetime import datetime

from PIL import Image, ImageDraw, ImageFont

try:
    from zoneinfo import ZoneInfo
    ZEIT = ZoneInfo("Europe/Berlin")
except Exception:  # tzdata fehlt -> lokale Zeit
    ZEIT = None

# ------------------------------------------------------------- EINSTELLUNGEN
LATITUDE = 52.52
LONGITUDE = 13.41
ORT = "Berlin"
TIMEZONE = "Europe/Berlin"

WIDTH, HEIGHT = 1072, 1448   # Kindle Paperwhite 3 (7. Generation)

OUTPUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "www", "dashboard.png")
# ----------------------------------------------------------------------------

WETTER_CODES = {
    0: "Klar", 1: "Überwiegend klar", 2: "Teils bewölkt", 3: "Bedeckt",
    45: "Nebel", 48: "Reifnebel",
    51: "Leichter Nieselregen", 53: "Nieselregen", 55: "Starker Nieselregen",
    56: "Gefrierender Nieselregen", 57: "Gefrierender Nieselregen",
    61: "Leichter Regen", 63: "Regen", 65: "Starker Regen",
    66: "Gefrierender Regen", 67: "Gefrierender Regen",
    71: "Leichter Schneefall", 73: "Schneefall", 75: "Starker Schneefall",
    77: "Schneegriesel",
    80: "Leichte Schauer", 81: "Schauer", 82: "Starke Schauer",
    85: "Schneeschauer", 86: "Starke Schneeschauer",
    95: "Gewitter", 96: "Gewitter mit Hagel", 99: "Gewitter mit Hagel",
}
WOCHENTAGE = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
MONATE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli",
          "August", "September", "Oktober", "November", "Dezember"]


def g(v):
    """Auf ganze Zahl runden, ohne '-0'."""
    return str(int(round(v)))


def hole_wetter():
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={LATITUDE}&longitude={LONGITUDE}"
        "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
        f"&timezone={TIMEZONE}&forecast_days=4"
    )
    with urllib.request.urlopen(url, timeout=20) as antwort:
        return json.load(antwort)


def demo_wetter():
    heute = datetime.now(ZEIT).date()
    tage = [heute.toordinal() + i for i in range(4)]
    return {
        "current": {"temperature_2m": 7.4, "apparent_temperature": 4.9,
                    "weather_code": 3, "wind_speed_10m": 14.2},
        "daily": {
            "time": [datetime.fromordinal(t).strftime("%Y-%m-%d") for t in tage],
            "weather_code": [3, 61, 2, 0],
            "temperature_2m_max": [8.1, 9.0, 6.5, 5.2],
            "temperature_2m_min": [3.2, 4.1, 1.0, -0.5],
            "precipitation_probability_max": [20, 80, 10, 0],
        },
    }


def schrift(groesse, fett=False):
    kandidaten = [
        r"C:\Windows\Fonts\arialbd.ttf" if fett else r"C:\Windows\Fonts\arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if fett
        else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for pfad in kandidaten:
        if os.path.exists(pfad):
            return ImageFont.truetype(pfad, groesse)
    try:
        return ImageFont.load_default(groesse)
    except TypeError:
        return ImageFont.load_default()


def rendern(daten):
    s = WIDTH / 600.0                      # Entwurf ist 600 Einheiten breit
    px = lambda v: int(v * s)

    bild = Image.new("L", (WIDTH, HEIGHT), 255)
    z = ImageDraw.Draw(bild)
    jetzt = datetime.now(ZEIT)

    def mitte(text, y, font, fill=0, cx=WIDTH // 2):
        b = z.textbbox((0, 0), text, font=font)
        z.text((cx - (b[2] - b[0]) // 2, y), text, font=font, fill=fill)

    # Kopf: Wochentag + Datum (keine Uhr - das Bild ist nur alle ~15 Min. frisch)
    mitte(WOCHENTAGE[jetzt.weekday()], px(30), schrift(px(64), True))
    mitte(f"{jetzt.day}. {MONATE[jetzt.month - 1]} {jetzt.year}", px(110), schrift(px(40)))
    z.line((px(40), px(172), WIDTH - px(40), px(172)), fill=0, width=max(2, px(3)))

    # Aktuelles Wetter
    aktuell = daten["current"]
    mitte(ORT, px(195), schrift(px(30)), fill=90)
    mitte(f"{g(aktuell['temperature_2m'])}°", px(222), schrift(px(170), True))
    mitte(WETTER_CODES.get(aktuell["weather_code"], "–"), px(415), schrift(px(46), True))
    mitte(f"Gefühlt {g(aktuell['apparent_temperature'])}°   ·   Wind {g(aktuell['wind_speed_10m'])} km/h",
          px(475), schrift(px(30)))
    z.line((px(40), px(528), WIDTH - px(40), px(528)), fill=0, width=max(2, px(3)))

    # Vorschau naechste 3 Tage
    tag = daten["daily"]
    spalte = WIDTH // 3
    for i in range(1, 4):
        d = datetime.strptime(tag["time"][i], "%Y-%m-%d")
        cx = (i - 1) * spalte + spalte // 2
        mitte(WOCHENTAGE[d.weekday()][:2], px(556), schrift(px(42), True), cx=cx)
        mitte(f"{g(tag['temperature_2m_max'][i])}° / {g(tag['temperature_2m_min'][i])}°",
              px(614), schrift(px(34)), cx=cx)
        mitte(f"Regen {tag['precipitation_probability_max'][i]}%", px(662), schrift(px(26)), cx=cx)
        code = WETTER_CODES.get(tag["weather_code"][i], "–")
        mitte(code if len(code) <= 14 else code[:13] + ".", px(700), schrift(px(24)), cx=cx)

    # Stand
    mitte(f"Aktualisiert {jetzt.strftime('%H:%M')} Uhr", HEIGHT - px(46), schrift(px(22)), fill=110)
    return bild


def main():
    try:
        daten = demo_wetter() if "--demo" in sys.argv else hole_wetter()
    except Exception as fehler:
        print("Wetterdaten konnten nicht geladen werden:", fehler)
        sys.exit(1)

    os.makedirs(os.path.dirname(OUTPUT), exist_ok=True)
    rendern(daten).save(OUTPUT, "PNG")
    print("Gespeichert:", OUTPUT, f"({WIDTH}x{HEIGHT})")


if __name__ == "__main__":
    main()
